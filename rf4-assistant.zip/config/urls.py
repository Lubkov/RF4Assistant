from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("fish/", include("fish.urls")),
    path("records/", include("records.urls")),
    path("maps/", include("waterbodies.urls")),
    path("", include("core.urls")),
]

# Uploaded images are served by Django only during local development.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
